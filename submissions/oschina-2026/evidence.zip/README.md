# Morphogenesis 三框架并发实测证据（2026-10-30）

## 优先阅读
- `analysis/report.md`：独立复核、15组合全表、每组合失败分类及证据边界。
- `analysis/arms.csv`、`analysis/analysis.json`：正式展示数据；15×48槽，720唯一HTTP请求，完整性PASS。
- `pilot/report.json`：未经改写的原始终态报告；`pilot/summary.csv`是原runner汇总。
- `pilot/block-*/.../model-results/*.json`：全部720个逐响应原始脱敏记录。
- `analysis/failures.csv`保留全部88个未通过：74个length截断、11个正常终止答案不匹配、3个格式不合规；不得把85个incorrect全叫算术错误。

## 固定协议与解释
源基准 `eff9611f6c630f710bf47d723710c4dbe5e23ba4`；模型 `step-3.5-flash`；官方中国区 `https://api.stepfun.com/v1/chat/completions`。
同一48题GSM8K test、同一提示；并发1/2/3/4/5，Morphogenesis、AutoGen Core 0.7.5、LangGraph 1.2.18；每组合1轮；随机顺序seed20261030。
temperature=0、max_tokens=4096、stream=false、provider默认推理设置、无tools、无自动重试，单账户共享请求门禁上限5、pilot上限720。
具体顺序/系统提示/依赖版本/执行源码哈希在 `pilot/plan.json`，选择固定在 `pilot/selection.json`。
这是固定独立任务批处理吞吐与准确率试验，不是协作推理/去中心化优越性的证明；不是此前被阻断的SWA集成测试。
Morph本次c5为42/48、139.989秒、18.001正确/分钟，慢于本次两对照；不得只挑自身加速隐去该结果。
各组合一轮不支持速度置信区间、稳定线性加速或架构因果结论。
HTTP区间是客户端进入到返回，不是服务端GPU同时计算；整批耗时含原生准备、调度、提交持久化和收尾。
74个截断全部输出usage=4096；统一输出预算/模型推理开销是瓶颈假设，不能反推框架准确率优势。

## 费用与先前开发运行
官方价格来源 `pricing/pricing-source.json` 和公开网页快照；输入0.70、缓存输入0.14、输出2.10元/百万tokens，2026-10-30核验。
输入包含缓存。pilot720个usage与cache均完整，按价估算¥1.54272888；不是账单，实际扣款未知。
两个完成development各12调用共24，另估算¥0.02352434，不混入pilot。
`development-108f440-20261030`为初次前置失败，父控标记zero-send；旧报告仅有2个gate reservations、0个HTTP进入证据、0完成响应。reservation不等于请求已发送；仅凭缺日志不推断账单为0。保留原始中止记录，不回填成功。
独立reviewer的`related-runs/initial-108f440-presend-diagnosis.json`补充了构造器抛错发生在post前的来源/代码顺序核验；该说明明确源于已观测会话，不冒充原始逐请求日志，亦不构成供应商账单核销。
历史直接Pi结果不混入本包或本次排名。

## 证据选择与安全
这是白名单选择性证据包，不是运行目录全量复制。原始报告、逐响应、原生审计/交付结果按字节复制；新分析和48题摘录明确为派生文件。
保留Morph240个原生任务审计、240个交付结果、进程/worker最终状态、原生事件和runtime最终记录；不包含SQLite及侧写文件、git对象、执行worktree/资产副本、依赖环境、credential homes或auth配置。
本包未做新的字符串替换或答案修改；模型记录由原执行器在落盘前做密钥回显阻断。完整原件哈希与复制类型见`manifest.json`。
`safety-scan.json`是仅扫描本白名单内容的模式与canary错误标记检查，不是精确密钥证明；父控在上传前另做精确密钥扫描。打包器不读取密钥、没有调用API、没有上传。
原生lease.token是本地已结束任务租约标识，不是StepFun API凭据；不应用作任何外部授权。

## 离线复核
后处理器只有Python标准库；在`postprocessor`运行`python -m unittest -v test_postprocess_pilot.py`应为9项通过。
取得OpenAI GSM8K官方repo并固定`3101c7d5072418e28b9008a6636bde82a006892c`后，可执行（不会调用模型）：
```
python postprocessor/postprocess_pilot.py --run pilot --source /path/to/gsm8k-pinned \
  --output /new/analysis-output --terminal-confirmed \
  --related-run related-runs/development-e3abae3-20261030 \
  --related-run related-runs/development-eff9611-20261030 \
  --related-run related-runs/development-108f440-20261030
```
结果中的原绝对路径保留作来源审计，不能据此读取任何不存在的私有路径；上述CLI接受本地新路径。
`frozen-source/`仅是精确基准commit的关键模块和许可证，不是完整可执行产品分发；完整源码请与独立源码交付包一起使用。
重新开展付费实验须另由单一负责人明确审批，不要直接复用旧API会话或尝试第二把key绕过限额。
