#!/usr/bin/env python3
"""Independent, offline terminal pilot audit. Never imports a model executor.

Requires explicit parent terminal confirmation. Writes only a NEW output folder;
never changes run artifacts, the frozen source tree, credentials or model state.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
import subprocess
from collections import Counter

FRAMEWORKS = ('morphogenesis', 'autogen-core', 'langgraph')
LEVELS = (1, 2, 3, 4, 5)
EXPECTED_TASKS = 48
REVISION = '3101c7d5072418e28b9008a6636bde82a006892c'
ANSWER_RE = re.compile(r'#### (\-?[0-9\.\,]+)')
SYSTEM_PREFIX = 'You are a careful mathematics solver. Solve the supplied problem without tools. '
RATES = {'input': Decimal('0.70'), 'cached_input': Decimal('0.14'), 'output': Decimal('2.10')}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def extract_answer(text):
    match = ANSWER_RE.search(text) if isinstance(text, str) else None
    return match.group(1).strip().replace(',', '') if match else None


def classify(record, target):
    if record is None or record.get('status') != 'completed':
        return 'missing'
    if record.get('evidence', {}).get('model_outcome') in ('truncated', 'filtered'):
        return 'incorrect'
    answer = extract_answer(record.get('text'))
    if answer is None:
        return 'malformed'
    return 'correct' if answer == target else 'incorrect'


def usage_cost(usage):
    """prompt_tokens INCLUDES cached_tokens. Missing cache breakdown is unknown."""
    if usage is None:
        return {'valid': False, 'reason': 'usage_unknown', 'low': None, 'high': None, 'point': None}
    if not isinstance(usage, dict):
        return {'valid': False, 'reason': 'usage_invalid_type', 'low': None, 'high': None, 'point': None}
    names = ('prompt_tokens', 'completion_tokens', 'total_tokens')
    if any(type(usage.get(name)) is not int or usage[name] < 0 for name in names):
        return {'valid': False, 'reason': 'usage_invalid_counts', 'low': None, 'high': None, 'point': None}
    prompt, completion, total = (usage[name] for name in names)
    if total != prompt + completion:
        return {'valid': False, 'reason': 'usage_total_mismatch', 'low': None, 'high': None, 'point': None}
    cached = usage.get('cached_tokens')
    if 'cached_tokens' in usage and (type(cached) is not int or not 0 <= cached <= prompt):
        return {'valid': False, 'reason': 'cached_tokens_out_of_range', 'low': None, 'high': None, 'point': None}
    def amount(cache):
        return float(((prompt - cache) * RATES['input'] + cache * RATES['cached_input'] + completion * RATES['output']) / Decimal(1000000))
    return {'valid': True, 'reason': None, 'cached_known': cached is not None,
            'low': amount(cached if cached is not None else prompt),
            'high': amount(cached if cached is not None else 0),
            'point': amount(cached) if cached is not None else None,
            'prompt': prompt, 'completion': completion, 'total': total, 'cached': cached}


def percentile(values, fraction):
    values = sorted(values)
    return values[max(0, math.ceil(fraction * len(values)) - 1)] if values else None


def wilson(correct, total):
    if total == 0:
        return None, None
    z = 1.959963984540054
    p = correct / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def overlap(intervals):
    events = [(start, 1) for start, end in intervals] + [(end, -1) for start, end in intervals]
    active = peak = 0
    for _, change in sorted(events, key=lambda row: (row[0], row[1])):
        active += change
        peak = max(peak, active)
    return peak


def paired_result(a, b, draws, seed):
    assert len(a) == len(b) and len(a) > 0
    counts = Counter((int(x), int(y)) for x, y in zip(a, b))
    differences = [int(x) - int(y) for x, y in zip(a, b)]
    rng = random.Random(seed)
    samples = sorted(sum(rng.choices(differences, k=len(differences))) / len(differences) * 100 for _ in range(draws)) if draws else []
    return {'paired_tasks': len(a), 'both_correct': counts[(1, 1)], 'a_only_correct': counts[(1, 0)],
            'b_only_correct': counts[(0, 1)], 'both_wrong': counts[(0, 0)],
            'accuracy_difference_pp_a_minus_b': sum(differences) / len(differences) * 100,
            'paired_task_bootstrap95_low_pp': percentile(samples, .025),
            'paired_task_bootstrap95_high_pp': percentile(samples, .975),
            'bootstrap_draws': draws, 'bootstrap_seed': seed,
            'interval_scope': 'descriptive paired task resampling only; not run-to-run, speed, or architecture confidence; no multiplicity correction'}


class Audit:
    def __init__(self):
        self.errors, self.warnings, self.inputs = [], [], {}

    def require(self, condition, code, detail=None):
        if not condition:
            self.errors.append({'code': code, 'detail': detail})
        return bool(condition)

    def read(self, path):
        data = path.read_bytes()
        self.inputs[str(path)] = sha256(data)
        return json.loads(data)


def read_selection(audit, run, source, plan):
    selection = audit.read(run / 'selection.json')
    revision = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
    audit.require(revision == selection['source_revision'] == REVISION, 'dataset_revision_mismatch')
    raw = (source / 'grade_school_math/data/test.jsonl').read_bytes()
    audit.inputs[str(source / 'grade_school_math/data/test.jsonl')] = sha256(raw)
    audit.require(sha256(raw) == selection['source_file_sha256'], 'dataset_bytes_mismatch')
    audit.require(selection['split'] == 'test' and selection['count'] == EXPECTED_TASKS, 'selection_not_test48')
    data = [json.loads(line) for line in raw.splitlines()]
    ordered = sorted(enumerate(data), key=lambda row: (sha256((selection['selection_prefix'] + row[1]['question']).encode()), row[0]))[:EXPECTED_TASKS]
    audit.require([index for index, row in ordered] == [row['line_index'] for row in selection['samples']], 'deterministic_selection_mismatch')
    audit.require(plan['system_prompt'].startswith(SYSTEM_PREFIX), 'system_prompt_prefix_unrecognized')
    instruction = plan['system_prompt'][len(SYSTEM_PREFIX):]
    examples = []
    for sample in selection['samples']:
        row = data[sample['line_index']]
        prompt = 'Solve this mathematics problem. ' + instruction + '\n\n' + row['question']
        target = extract_answer(row['answer'])
        audit.require(target is not None, 'official_gold_parse_failed', sample['sample_id'])
        audit.require(sha256(row['question'].encode()) == sample['question_sha256'], 'question_hash_mismatch', sample['sample_id'])
        audit.require(sha256(prompt.encode()) == sample['prompt_sha256'], 'prompt_hash_mismatch', sample['sample_id'])
        payload = {'model': plan['model'], 'stream': False, 'max_tokens': plan['max_tokens'],
                   'temperature': plan['temperature'], 'messages': [
                       {'role': 'system', 'content': plan['system_prompt']}, {'role': 'user', 'content': prompt}]}
        examples.append({'id': sample['sample_id'], 'target': target,
                         'payload_sha256': sha256(json.dumps(payload, ensure_ascii=False, allow_nan=False).encode())})
    return examples


def analyze_arm(audit, arm, examples, plan, run_id, global_requests):
    framework, concurrency = arm['framework'], arm['concurrency']
    label = f'{framework}/c{concurrency}'
    by_id = {}
    for record in arm.get('records', []):
        by_id.setdefault(record.get('task_id'), []).append(record)
    audit.require(len(arm.get('records', [])) == EXPECTED_TASKS, 'arm_record_count_not48', label)
    audit.require(set(by_id) == {e['id'] for e in examples}, 'arm_inventory_mismatch', label)
    rows, intervals, leaf_latency, queue_latency, costs = [], [], [], [], []
    clocks, request_ordinals = set(), set()
    for example in examples:
        matches = by_id.get(example['id'], [])
        audit.require(len(matches) == 1, 'task_duplicate_or_missing', f"{label}/{example['id']}")
        record = matches[0] if len(matches) == 1 else None
        grade = 'duplicate' if len(matches) > 1 else classify(record, example['target'])
        evidence = record.get('evidence', {}) if record else {}
        status = record.get('status', 'missing_record') if record else 'missing_record'
        ordinal = evidence.get('request_ordinal')
        clock = evidence.get('clock')
        if type(ordinal) is int:
            request_ordinals.add(ordinal)
            identity = (clock.get('id') if isinstance(clock, dict) else None, ordinal)
            audit.require(identity not in global_requests, 'duplicate_request_identity', str(identity))
            global_requests.add(identity)
            audit.require(isinstance(clock, dict) and clock.get('kind') == 'host-monotonic', 'request_clock_invalid', label)
            clocks.add(json.dumps(clock, sort_keys=True))
            audit.require(evidence.get('run_id') == run_id and evidence.get('framework') == framework
                          and evidence.get('block_id') == arm['block_id'] and evidence.get('task_id') == example['id'],
                          'request_identity_mismatch', f"{label}/{example['id']}")
            audit.require(evidence.get('attempt') == 1 and evidence.get('retry_count') == 0, 'unexpected_attempt_or_retry', label)
            audit.require(evidence.get('provenance') == 'live', 'nonlive_request_evidence', label)
            audit.require(evidence.get('payload_sha256') == example['payload_sha256'], 'payload_parity_mismatch', f"{label}/{example['id']}")
            settings = evidence.get('request_settings', {})
            expected = {'url': 'https://api.stepfun.com/v1/chat/completions', 'model': plan['model'],
                        'system_prompt': plan['system_prompt'], 'max_tokens': plan['max_tokens'],
                        'temperature': plan['temperature'], 'stream': False, 'tools': None,
                        'reasoning_effort': None, 'provider_seed': None}
            audit.require(settings == expected, 'request_settings_mismatch', label)
        start, end = evidence.get('http_entered_at_ns'), evidence.get('http_returned_at_ns')
        interval = type(start) is int and type(end) is int and 0 < start < end
        if interval:
            intervals.append((start, end))
        if status == 'completed':
            audit.require(evidence.get('http_status') == 200, 'completed_without_http200', label)
            audit.require(evidence.get('model_outcome') in ('completed', 'truncated', 'filtered'), 'unknown_completed_outcome', label)
            audit.require(interval, 'completed_without_http_interval', label)
            if interval:
                leaf_latency.append((end - start) / 1e9)
            ordered_times = [evidence.get(name) for name in ('queued_at_ns', 'permit_acquired_at_ns', 'http_entered_at_ns',
                'response_headers_at_ns', 'first_body_byte_at_ns', 'last_body_byte_at_ns', 'http_returned_at_ns', 'ended_at_ns')]
            audit.require(all(type(value) is int for value in ordered_times) and
                          all(left <= right for left, right in zip(ordered_times, ordered_times[1:])),
                          'request_timestamp_order_invalid', f"{label}/{example['id']}")
        queued, acquired = evidence.get('queued_at_ns'), evidence.get('permit_acquired_at_ns')
        if type(queued) is int and type(acquired) is int and acquired >= queued:
            queue_latency.append((acquired - queued) / 1e9)
        cost = usage_cost(record.get('usage')) if record else usage_cost(None)
        if ordinal is not None:
            costs.append(cost)
        if record and record.get('usage') is not None:
            audit.require(cost['valid'], 'invalid_usage', {'arm': label, 'task_id': example['id'], 'reason': cost['reason']})
        rows.append({'framework': framework, 'concurrency': concurrency, 'block_id': arm['block_id'],
            'task_id': example['id'], 'response_status': status, 'strict_score': grade,
            'timeline_request_id': f"{arm['block_id']}-request-{len(rows)+1:03d}",
            '_http_start_ns': start if interval else None, '_http_end_ns': end if interval else None,
            'is_correct': grade == 'correct', 'extracted_answer': extract_answer(record.get('text')) if record else None,
            'expected_answer': example['target'], 'model_outcome': evidence.get('model_outcome'),
            'official_extracted_exact_match': extract_answer(record.get('text')) == example['target'] if record else False,
            'single_marker': isinstance(record.get('text'), str) and len(ANSWER_RE.findall(record['text'])) == 1 if record else False,
            'finish_reason': evidence.get('finish_reason'), 'error_kind': evidence.get('error_kind'),
            'http_status': evidence.get('http_status'), 'request_ordinal': ordinal,
            'request_id': record.get('request_id') if record else None,
            'http_active_seconds': (end - start) / 1e9 if interval else None,
            'usage_valid': cost['valid'], 'usage_issue': cost['reason'],
            'prompt_tokens': cost.get('prompt'), 'completion_tokens': cost.get('completion'),
            'cached_tokens': cost.get('cached'), 'total_tokens': cost.get('total'),
            'estimated_cost_cny': cost['point'], 'known_usage_cost_low_cny': cost['low'],
            'known_usage_cost_high_cny': cost['high'], 'unknown_remote_effect': evidence.get('unknown_remote_effect')})
    counts = Counter(row['strict_score'] for row in rows)
    origin = min((start for start, end in intervals), default=None)
    for row in rows:
        start, end = row.pop('_http_start_ns'), row.pop('_http_end_ns')
        row['http_start_offset_ms'] = (start-origin)/1e6 if start is not None and origin is not None else None
        row['http_end_offset_ms'] = (end-origin)/1e6 if end is not None and origin is not None else None
        row['timeline_scope'] = 'same arm first HTTP enter = 0; client HTTP activity only, not token streaming/GPU'
    completed = sum(row['response_status'] == 'completed' for row in rows)
    valid_arm = arm['status'] == 'COMPLETED' and completed == EXPECTED_TASKS and len(arm.get('records', [])) == EXPECTED_TASKS
    wall = arm.get('wall_seconds')
    audit.require(not valid_arm or isinstance(wall, (int, float)) and wall > 0, 'invalid_completed_wall_time', label)
    if arm['status'] == 'COMPLETED':
        audit.require(valid_arm and arm.get('native_delivery_complete') is True and arm.get('model_inventory_complete') is True,
                      'completed_arm_delivery_incomplete', label)
        if framework == 'morphogenesis':
            native = arm.get('native_runtime', {})
            processes = native.get('processes', [])
            audit.require(len(processes) == concurrency and len({p['pid'] for p in processes}) == concurrency
                          and all(p.get('exit_code') == 0 and p.get('alive') is False for p in processes)
                          and native.get('owned_workers_exited') is True and not native.get('forced_termination_pids')
                          and native.get('interrupted') is False, 'native_worker_cleanup_incomplete', label)
            audit.require(all(r.get('native_task', {}).get('status') == 'completed'
                          and r['native_task'].get('attempts') == 1 and r['native_task'].get('effect_applied') is True
                          for r in arm['records']), 'native_task_delivery_incomplete', label)
    peak = overlap(intervals) if len(clocks) == 1 else None
    audit.require(not request_ordinals or len(clocks) == 1, 'arm_multiple_clocks', label)
    audit.require(peak is None or peak <= concurrency, 'http_peak_exceeds_configured', label)
    known = [cost for cost in costs if cost['valid']]
    unknown_usage = len(costs) - len(known)
    complete_cost = bool(costs) and not unknown_usage and all(cost['point'] is not None for cost in known)
    point = math.fsum(cost['point'] for cost in known) if complete_cost else None
    accuracy = counts['correct'] / EXPECTED_TASKS if valid_arm else None
    ci_low, ci_high = wilson(counts['correct'], EXPECTED_TASKS) if valid_arm else (None, None)
    summary = {'framework': framework, 'concurrency': concurrency, 'block_id': arm['block_id'], 'ordinal': arm['ordinal'],
        'status': arm['status'], 'requested': EXPECTED_TASKS, 'completed_responses': completed,
        **{name: counts[name] for name in ('correct', 'incorrect', 'malformed', 'missing', 'duplicate')},
        'accuracy': accuracy, 'accuracy_wilson95_low': ci_low, 'accuracy_wilson95_high': ci_high,
        'wall_seconds': wall, 'performance_comparable': valid_arm,
        'wall_timing_scope': 'end-to-end arm including native preparation, scheduling, model calls, durable delivery and teardown; not pure HTTP',
        'native_runtime_wall_seconds': arm.get('native_runtime', {}).get('wall_seconds'),
        'http_span_seconds': (max(end for start, end in intervals) - min(start for start, end in intervals)) / 1e9 if intervals else None,
        'http_request_seconds_sum': math.fsum((end-start)/1e9 for start, end in intervals),
        'correct_per_minute': counts['correct'] * 60 / wall if valid_arm else None,
        'batch_speedup_vs_own_c1': None, 'parallel_efficiency_vs_own_c1': None,
        'correct_throughput_ratio_vs_own_c1': None,
        'client_http_peak': peak, 'http_interval_count': len(intervals), 'http_request_count': len(request_ordinals),
        'completed_http_latency_p50_s': percentile(leaf_latency, .5), 'completed_http_latency_p95_s': percentile(leaf_latency, .95),
        'queue_wait_p50_s': percentile(queue_latency, .5), 'queue_wait_p95_s': percentile(queue_latency, .95),
        'usage_known_requests': len(known), 'usage_unknown_requests': unknown_usage,
        'cache_breakdown_unknown_requests': sum(not cost['cached_known'] for cost in known),
        'prompt_tokens_known': sum(cost['prompt'] for cost in known),
        'completion_tokens_known': sum(cost['completion'] for cost in known),
        'total_tokens_known': sum(cost['total'] for cost in known),
        'cached_tokens_known': sum(cost['cached'] for cost in known if cost['cached_known']),
        'known_usage_estimate_low_cny': math.fsum(cost['low'] for cost in known) if known else None,
        'known_usage_estimate_high_cny': math.fsum(cost['high'] for cost in known) if known else None,
        'estimated_total_cost_cny': point, 'estimate_covers_all_observed_requests': complete_cost,
        'estimated_cost_per_correct_cny': point / counts['correct'] if valid_arm and point is not None and counts['correct'] else None,
        'actual_invoice_cost_cny': None,
        'completed_answer_mismatch': sum(row['strict_score'] == 'incorrect' and row['model_outcome'] == 'completed' for row in rows),
        'truncated': sum(row['model_outcome'] == 'truncated' for row in rows),
        'filtered': sum(row['model_outcome'] == 'filtered' for row in rows),
        'provider_429': sum(row['http_status'] == 429 for row in rows)}
    if 'evaluation' in arm:
        for name in ('correct', 'incorrect', 'malformed', 'missing', 'duplicate'):
            audit.require(arm['evaluation'][name] == counts[name], 'independent_score_disagrees', {'arm': label, 'metric': name})
    return summary, rows, intervals


def summarize_related(audit, paths):
    rows = []
    for path in paths:
        report_file = path / 'report.json'
        if not report_file.is_file():
            rows.append({'path': str(path), 'scope': 'separate_nonpilot_record', 'status': 'NO_TERMINAL_REPORT',
                         'request_reservations': None, 'http_entered_evidence_count': None,
                         'note': 'No cost or zero-call claim inferred from a missing report'})
            continue
        report = audit.read(report_file)
        records = [r for arm in report.get('arms', []) for r in arm.get('records', [])]
        costs = [usage_cost(record.get('usage')) for record in records if record.get('evidence', {}).get('request_ordinal') is not None]
        known = [cost for cost in costs if cost['valid']]
        exact = bool(costs) and len(known) == len(costs) and all(cost['point'] is not None for cost in known)
        rows.append({'path': str(path), 'scope': 'separate_nonpilot_record', 'mode': report.get('mode'),
            'status': report.get('status'), 'request_reservations': report.get('gate', {}).get('reserved_requests'),
            'http_entered_evidence_count': sum(type(r.get('evidence', {}).get('http_entered_at_ns')) is int for r in records),
            'completed_responses': sum(r.get('status') == 'completed' for r in records),
            'active_reservations_terminal': report.get('gate', {}).get('active_reservations'),
            'estimated_known_usage_cost_cny': math.fsum(c['point'] for c in known) if exact else None,
            'actual_invoice_cost_cny': None,
            'note': 'Excluded from pilot comparisons; gate reservations are not HTTP sends; absent HTTP evidence alone does not prove zero remote effects'})
    return rows


def write_csv(path, rows):
    if not rows:
        path.write_text('')
        return
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('x', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader(); writer.writerows(rows)


def render_report(result):
    def fmt(value, places=3):
        return '—' if value is None else f'{value:.{places}f}'
    totals = {name: sum(row[name] for row in result['arms']) for name in
              ('correct', 'completed_answer_mismatch', 'malformed', 'truncated', 'filtered',
               'prompt_tokens_known', 'completion_tokens_known', 'cached_tokens_known')}
    lines = ['# GSM8K 三框架并发探索性试验独立复核', '',
        f"运行状态：**{result['run_status']}**；独立完整性检查：**{result['validation_status']}**。",
        '同一模型、同一组 48 题、并发 1–5、三框架各组合仅一次。测试的是固定独立任务批处理，不是协作推理或架构优越性的证明。', '',
        f"严格正确合计 {totals['correct']}/720；失败分解为协议截断 {totals['truncated']}、过滤 {totals['filtered']}、正常终止但最终答案字符串不匹配 {totals['completed_answer_mismatch']}、正常终止格式不合规 {totals['malformed']}。截断不能统称算术错误。", '',
        '| 框架 | 并发 | 状态 | 严格正确/48 | 准确率 | 整批秒 | 正确/分钟 | 对自身c1耗时加速比 | 每正确题估算元 |',
        '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for row in result['arms']:
        lines.append(f"| {row['framework']} | {row['concurrency']} | {row['status']} | {row['correct']}/48 | {fmt(None if row['accuracy'] is None else row['accuracy']*100, 2)}% | {fmt(row['wall_seconds'])} | {fmt(row['correct_per_minute'])} | {fmt(row['batch_speedup_vs_own_c1'])} | {fmt(row['estimated_cost_per_correct_cny'], 6)} |")
    lines += ['', '未完成组合的耗时仅为中止/收尾时长；其完整准确率、吞吐、速度比与每正确题费用留空，不当作零值排名。正确数只表示已观测严格通过数量；取消或未运行不等于完成后的错误答案。', '',
        '### 每组合失败分解', '',
        '| 框架 | 并发 | 截断 length | 过滤 | 正常终止答案不匹配 | 正常终止格式不合规 |',
        '|---|---:|---:|---:|---:|---:|']
    for row in result['arms']:
        lines.append(f"| {row['framework']} | {row['concurrency']} | {row['truncated']} | {row['filtered']} | {row['completed_answer_mismatch']} | {row['malformed']} |")
    lines += ['',
        f"已知输入 {totals['prompt_tokens_known']:,} tokens（其中缓存 {totals['cached_tokens_known']:,}，已包含在输入中）、输出 {totals['completion_tokens_known']:,} tokens。统一 max_tokens=4096；本次所有 length 截断响应的 completion_tokens 均为4096。输出预算及模型推理开销可能是重要瓶颈，但本证据没有独立 reasoning token 分项，不能归因为框架造成的准确率差异。", '',
        '## 评分与对照',
        '独立实现官方 GSM8K 的第一个 `#### ` 正则匹配、去逗号、精确字符串比较；无数值容差。另按预先冻结协议将 truncated/filtered 判失败，即使部分文本包含正确标记。所有48题保留分母；逐题失败、缺失、重复、过滤和截断均留存。',
        '`paired_scores.csv` 给出相同并发下同48题的同对、A独对、B独对、同错计数。附带区间仅为固定题目配对重采样的描述，不覆盖运行随机性，未做多重比较校正，不能据此宣称架构显著更优。', '',
        '## 时间与费用',
        '主表整批时间包含原生准备、调度、模型请求、结果持久化/提交及清理；Morphogenesis还包含任务库/目标准备和持久交付。HTTP延迟单列，只量客户端进入到响应读取/连接收尾。HTTP区间总和可因并发超过整批时间；两者不能混为纯调度开销。各适配器的持久化义务不同，也不能把总时间差直接归因为架构本身。',
        '耗时加速比=本框架c1整批秒/本框架当前并发整批秒；正确吞吐比单列，不能与纯耗时加速混用。每组合只有一次，**不报告速度置信区间或稳定线性加速结论**。生成长度、缓存、网络、供应商队列和随机执行顺序均可能影响结果。',
        '费用依据 [StepFun 中国区官方定价](https://platform.stepfun.com/docs/zh/pricing/details)，核验日2026-10-30：未缓存输入0.70、缓存输入0.14、输出2.10元/百万token。prompt包含cached，避免重复计费；强制检查cached≤prompt。缺少缓存明细只给已知用量的估算范围；缺少usage不当成0。估算不是账单，实际扣款仍未知。',
        '开发运行、初次零发送中止和此前Pi基线均与主试验分开。`related_runs.csv` 只列明确传入的独立运行，不混入主pilot的准确率、加速比或费用。', '',
        '## 证据边界',
        'HTTP峰值来自同一主机单调时钟上的真实客户端请求进入/返回区间，不是stream输出窗口，更不是服务端GPU同时计算证明。原始记录只读；未读取key、未调用模型、未修改冻结源码。',
        f"完整性错误数：{len(result['validation_errors'])}；详见 `analysis.json`。输入文件哈希见 `inputs.sha256.json`。",
        '本报告与CSV保留全部组合和失败，不事后挑题、不修复答案、不只展示最好并发。']
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--pricing-source', type=Path, default=Path(__file__).with_name('pricing-source.json'))
    parser.add_argument('--related-run', type=Path, action='append', default=[])
    parser.add_argument('--bootstrap-draws', type=int, default=10000)
    parser.add_argument('--terminal-confirmed', action='store_true')
    args = parser.parse_args()
    if not args.terminal_confirmed:
        parser.error('Parent terminal confirmation is required; no live pilot processing')
    if not 0 <= args.bootstrap_draws <= 100000:
        parser.error('bootstrap draws must be 0..100000')
    audit = Audit()
    run = args.run.resolve(strict=True)
    report = audit.read(run / 'report.json')
    if report.get('status') not in ('COMPLETED', 'ABORTED') or report.get('gate', {}).get('active_reservations') != 0:
        raise RuntimeError('Not a drained terminal report; refusing analysis')
    plan, started, pricing = audit.read(run / 'plan.json'), audit.read(run / 'run-started.json'), audit.read(args.pricing_source)
    audit.require(plan == started['plan'], 'run_plan_changed')
    audit.require(plan['mode'] == report['mode'] == 'pilot', 'not_primary_pilot')
    audit.require(plan['repeats'] == 1 and plan['tasks_per_arm'] == 48 and plan['maximum_requests'] == 720, 'unexpected_frozen_design')
    audit.require(plan['automatic_retries'] == 0 and plan['stream'] is False, 'unexpected_transport_mode')
    audit.require(pricing['model'] == plan['model'] == 'step-3.5-flash', 'pricing_model_mismatch')
    audit.require(pricing['rates_cny_per_million'] == {name: float(rate) for name, rate in RATES.items()}, 'pricing_rate_mismatch')
    expected = {(framework, c) for framework in FRAMEWORKS for c in LEVELS}
    audit.require(len(plan['arms']) == len(report['arms']) == 15, 'terminal_arm_count_not15')
    audit.require({(a['framework'], a['concurrency']) for a in plan['arms']} == expected, 'planned_arm_set_mismatch')
    audit.require([(a['framework'], a['concurrency']) for a in report['arms']] == [(a['framework'], a['concurrency']) for a in plan['arms']], 'actual_arm_order_mismatch')
    examples = read_selection(audit, run, args.source.resolve(strict=True), plan)
    summaries, task_rows, all_intervals, identities = [], [], [], set()
    for arm in report['arms']:
        artifact = run / arm['block_id'] / 'result.json'
        if arm['status'] != 'NOT_RUN':
            audit.require(artifact.is_file() and audit.read(artifact) == arm, 'arm_artifact_mismatch', arm['block_id'])
        summary, rows, intervals = analyze_arm(audit, arm, examples, plan, report['run_id'], identities)
        summaries.append(summary); task_rows.extend(rows); all_intervals.extend(intervals)
    audit.require(len(identities) == report['gate']['reserved_requests'], 'reserved_request_count_mismatch')
    audit.require(len({identity[0] for identity in identities}) <= 1, 'global_clock_mismatch')
    audit.require({identity[1] for identity in identities} == set(range(1, len(identities)+1)), 'request_ordinal_gap')
    audit.require(len(identities) <= 720, 'pilot_budget_exceeded')
    audit.require(overlap(all_intervals) <= 5, 'global_http_cap_exceeded')
    if report['status'] == 'COMPLETED':
        audit.require(len(identities) == 720 and all(r['performance_comparable'] for r in summaries), 'completed_pilot_incomplete')
    for row in summaries:
        base = next((r for r in summaries if r['framework'] == row['framework'] and r['concurrency'] == 1), None)
        if row['performance_comparable'] and base and base['performance_comparable']:
            row['batch_speedup_vs_own_c1'] = base['wall_seconds'] / row['wall_seconds']
            row['parallel_efficiency_vs_own_c1'] = row['batch_speedup_vs_own_c1'] / row['concurrency']
            row['correct_throughput_ratio_vs_own_c1'] = row['correct_per_minute'] / base['correct_per_minute'] if base['correct_per_minute'] else None
    paired = []
    for c in LEVELS:
        for a, b in itertools.combinations(FRAMEWORKS, 2):
            arm_a = next((row for row in summaries if row['framework'] == a and row['concurrency'] == c), None)
            arm_b = next((row for row in summaries if row['framework'] == b and row['concurrency'] == c), None)
            if arm_a and arm_b and arm_a['performance_comparable'] and arm_b['performance_comparable']:
                a_scores = [row['is_correct'] for row in task_rows if row['framework'] == a and row['concurrency'] == c]
                b_scores = [row['is_correct'] for row in task_rows if row['framework'] == b and row['concurrency'] == c]
                seed = int(sha256(f'paired-v1:{a}:{b}:{c}'.encode())[:8], 16)
                paired.append({'framework_a': a, 'framework_b': b, 'concurrency': c, 'status': 'DESCRIPTIVE_PAIRED', **paired_result(a_scores, b_scores, args.bootstrap_draws, seed)})
            else:
                paired.append({'framework_a': a, 'framework_b': b, 'concurrency': c, 'status': 'NOT_COMPARABLE_ABORTED_OR_MISSING'})
    related = summarize_related(audit, args.related_run)
    for name, original_hash in audit.inputs.items():
        audit.require(sha256(Path(name).read_bytes()) == original_hash, 'input_changed_during_analysis', name)
    summaries.sort(key=lambda row: (FRAMEWORKS.index(row['framework']), row['concurrency']))
    result = {'schema': 'independent.gsm8k-pilot-analysis.v1', 'generated_at': datetime.now(timezone.utc).isoformat(),
        'run': str(run), 'run_status': report['status'], 'validation_status': 'PASS' if not audit.errors else 'FAIL',
        'validation_errors': audit.errors, 'warnings': audit.warnings, 'source_revision': plan['source_revision'],
        'dataset_revision': REVISION, 'repetitions_per_arm': 1, 'expected_arms': 15, 'observed_arms': len(summaries),
        'expected_task_slots': 720, 'observed_task_slots': len(task_rows), 'unique_http_requests': len(identities),
        'peak_client_http_global': overlap(all_intervals), 'pricing': pricing, 'actual_invoice_cost_cny': None,
        'arms': summaries, 'paired_scores': paired, 'per_task': task_rows, 'related_runs': related,
        'scope': 'independent fixed-task throughput and accuracy; not architecture/collaboration superiority',
        'model_calls_by_postprocessor': 0, 'credential_reads': 0, 'raw_source_artifacts_modified': False,
        'limitations': ['one run per arm; no speed confidence interval', 'paired bootstrap describes task resampling only',
            'fixed public tasks and potential contamination', 'order/cache/network/output-length confounding',
            'unknown usage and actual invoice never imputed as zero']}
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    for name, value in (('analysis.json', result), ('inputs.sha256.json', audit.inputs)):
        (args.output / name).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2)+'\n')
    write_csv(args.output / 'arms.csv', summaries)
    write_csv(args.output / 'tasks.csv', task_rows)
    write_csv(args.output / 'failures.csv', [row for row in task_rows if row['strict_score'] != 'correct'])
    write_csv(args.output / 'paired_scores.csv', paired)
    write_csv(args.output / 'related_runs.csv', related)
    (args.output / 'report.md').write_text(render_report(result))
    print(json.dumps({'validation': result['validation_status'], 'run_status': report['status'], 'output': str(args.output),
                      'arms': len(summaries), 'task_slots': len(task_rows), 'model_calls': 0}))
    return 0 if not audit.errors else 2


if __name__ == '__main__':
    raise SystemExit(main())
