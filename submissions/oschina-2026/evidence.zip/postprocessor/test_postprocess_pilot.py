"""Offline unit tests; never read an in-progress pilot or make network calls."""
import unittest
from postprocess_pilot import classify, extract_answer, usage_cost, paired_result, overlap, wilson, percentile


def row(text, outcome='completed', status='completed'):
    return {'text': text, 'status': status, 'evidence': {'model_outcome': outcome}}


class IndependentPostprocessorTests(unittest.TestCase):
    def test_official_first_marker_exact_not_numeric_tolerance(self):
        self.assertEqual(extract_answer('reason\n#### 1,234'), '1234')
        self.assertEqual(classify(row('#### 4.0'), '4'), 'incorrect')
        self.assertEqual(classify(row('#### 3\n#### 4'), '4'), 'incorrect')
        self.assertEqual(classify(row('answer is 4'), '4'), 'malformed')
        self.assertEqual(classify(row('#### -12'), '-12'), 'correct')

    def test_truncated_filtered_fail_and_canceled_is_not_wrong_answer(self):
        self.assertEqual(classify(row('#### 4', 'truncated'), '4'), 'incorrect')
        self.assertEqual(classify(row('#### 4', 'filtered'), '4'), 'incorrect')
        self.assertEqual(classify(row(None, None, 'canceled'), '4'), 'missing')
        self.assertEqual(classify(row(None, None, 'not_run'), '4'), 'missing')

    def test_cached_is_subtracted_from_prompt(self):
        result = usage_cost({'prompt_tokens': 1000000, 'completion_tokens': 1000000,
                             'total_tokens': 2000000, 'cached_tokens': 250000})
        self.assertTrue(result['valid'])
        self.assertAlmostEqual(result['point'], 2.66)
        self.assertEqual(result['point'], result['low'])
        self.assertEqual(result['point'], result['high'])

    def test_cache_over_prompt_negative_bool_or_inconsistent_usage_rejected(self):
        for usage in ({'prompt_tokens': 10, 'completion_tokens': 2, 'total_tokens': 12, 'cached_tokens': 11},
                      {'prompt_tokens': 10, 'completion_tokens': 2, 'total_tokens': 12, 'cached_tokens': -1},
                      {'prompt_tokens': True, 'completion_tokens': 2, 'total_tokens': 3},
                      {'prompt_tokens': 10, 'completion_tokens': 2, 'total_tokens': 13}):
            self.assertFalse(usage_cost(usage)['valid'])

    def test_missing_cache_has_range_not_imputed_zero(self):
        result = usage_cost({'prompt_tokens': 1000000, 'completion_tokens': 0, 'total_tokens': 1000000})
        self.assertIsNone(result['point'])
        self.assertEqual((result['low'], result['high']), (0.14, 0.70))

    def test_missing_usage_is_unknown_not_free(self):
        result = usage_cost(None)
        self.assertFalse(result['valid'])
        self.assertIsNone(result['point'])
        self.assertIsNone(result['low'])

    def test_overlap_is_half_open(self):
        self.assertEqual(overlap([(1, 2), (2, 3)]), 1)
        self.assertEqual(overlap([(1, 4), (2, 3), (2, 5)]), 3)

    def test_paired_counts_and_deterministic_interval(self):
        result = paired_result([True, True, False, False], [True, False, True, False], 1000, 1)
        self.assertEqual([result[k] for k in ('both_correct','a_only_correct','b_only_correct','both_wrong')], [1,1,1,1])
        self.assertEqual(result['accuracy_difference_pp_a_minus_b'], 0)
        self.assertEqual(result, paired_result([True, True, False, False], [True, False, True, False], 1000, 1))
        self.assertEqual(paired_result([True]*48, [False]*48, 100, 2)['paired_task_bootstrap95_low_pp'], 100)

    def test_summary_statistic_boundaries(self):
        low, high = wilson(48, 48)
        self.assertLess(low, 1)
        self.assertAlmostEqual(high, 1)
        self.assertEqual(percentile([4,1,2,3], .5), 2)
        self.assertIsNone(percentile([], .95))


if __name__ == '__main__':
    unittest.main()
